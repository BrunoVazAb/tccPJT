function menuShow() {
  let sideMenu = document.querySelector("#side-menu");

  if (sideMenu.classList.contains("open")) {
    sideMenu.classList.remove("open");
  } else {
    sideMenu.classList.add("open");
  }
}

document
  .getElementById("editarPerfil")
  .addEventListener("click", function (event) {
    event.preventDefault(); // Impede o redirecionamento padrão

    function abrirPopup() {
      // Exiba o pop-up
      document.body.classList.add("scroll-locked");

      document.getElementById("blur-background").style.display = "block";
      document.getElementById("popup").style.display = "block";

    }

    abrirPopup();
    document.getElementById("fecharPopup").addEventListener("click", function () {
        // Oculte o pop-up
        document.body.classList.remove("scroll-locked");
        document.getElementById("blur-background").style.display = "none";
        document.getElementById("popup").style.display = "none";
      });
  });

