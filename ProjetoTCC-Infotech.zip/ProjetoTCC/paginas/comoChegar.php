<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Paulo Agostinho Sobrinho</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="../CSS/styles.css">
        <link rel="stylesheet" href="../CSS/styles.css">

    </head>

    <body>
        <header id="header">
            <img id="logo" src="../imagens/Logo.png" alt="Logo do Site">
            <h1 >Paulo Agostinho Sobrinho</h1>
            <?php
                include ('funcoes.php');
            ?>
        </header>

        <nav id="side-menu">
            <ul>
                <button onclick="menuShow()" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                    </svg>
                </button>
                <li><a href="../index.php">Home</a></li>
                <li><a href="historia.php">História</a></li>
                <li><a href="comoChegar.php">Como Chegar</a></li>
                <li><a href="Desenvolvedores.php">Desenvolvedores</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="Bilheteria.php">Bilheteria</a></li>
            </ul>
        </nav>
          
        <script src="../JS/script.js"></script>
    </body>

    <footer>
        <div id="footer_content">
            <div id="footer_contacts">
                <h1>Conecte-se conosco </h1>
    
                <div id="footer_social_media">
                    <a href="#" class="footer-link" id="instagram">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                    <a href="#" class="footer-link" id="youtube">
                        <i class="fa-brands fa-youtube"></i>
                    </a>                
                    <a href="#" class="footer-link" id="twitter">
                        <i class="fa-brands fa-twitter" ></i>
                    </a>
                </div>
    
            </div>
            <ul class="footer-list">
                <li>
                    <h3> Blog </h3>
                </li>
                <li>
                    <a href="#" class="footer-link"> Home</a>
                </li>
                <li>
                    <a href="Desenvolvedores.php" class="footer-link"> Sobre nós</a>
                </li>            
    
            </ul>
    
            <ul class="footer-list">
                <li>
                    <h3> Produtos </h3>
                </li>
                <li>
                    <a href="#" class="footer-link"> App</a>
                </li>
                <li>
                    <a href="#" class="footer-link"> Desktop</a>
    
            </ul>
            <div id="footer_subscribe">
                <h3> Subscribe</h3>
                <p>
                    Enter your email to get notified about our news solutions 
                </p>
                <div id="input_group">
                    <input type="email" id="email">
                    <button>
                        <i class="fa-regular fa-envelope"></i>
                    </button>
                </div>
            </div>
        </div>
        <div id="footer_copyright">
            &#169
            2023 Todos os direitos reservados
        </div>
    </footer>
</html>