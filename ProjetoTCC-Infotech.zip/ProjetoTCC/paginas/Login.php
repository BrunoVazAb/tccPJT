<?php
    session_start();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        include('conexao.php');

        if (isset($_POST['usuario']) && isset($_POST['senha']) && !empty($_POST['usuario']) && !empty($_POST['senha'])) {
            $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
            $senhaDigitada = $_POST['senha'];
            $query = "SELECT id, senha FROM amigos_museu WHERE usuario = '{$usuario}'";
            $result = mysqli_query($conexao, $query);
            $row = mysqli_fetch_assoc($result);
        
            if ($row && password_verify($senhaDigitada, $row['senha'])) {
                $_SESSION['usuario'] = $usuario; 
                $_SESSION['id_usuario'] = $row['id'];
                header('Location: ../index.php');
                exit();
            } else {
                $_SESSION['nao_autenticado'] = true;
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Paulo Agostinho Sobrinho</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="../css/styles.css">
        <link rel="stylesheet" href="../css/login.css">
    </head>

    <body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>
            
        </div>

        <nav id="menu-userlog">
            <?php
                include "funcoes.php";
            ?>
        </nav>
        

    </header>
    <body>
        
        <nav id="side-menu">
            <ul>
                <li><button onclick="menuShow()" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                    </svg>
                </button></li><br><br>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>
        </nav>
        <div class="login">
            <p id= "plogin">Login </p>
            <hr>
                <?php
                    if(isset($_SESSION['nao_autenticado'])):
                ?>
                <div>
                    <p class="erro">Usuário ou senha inválidos.</p>
                </div>
                <?php
                    endif;
                    unset($_SESSION['nao_autenticado']);
                ?>
                <div class="box">
                    <form action="" method="POST">
                        <div class="dados">
                            <input name="usuario" type="text" placeholder="Digite o seu usuario">
                            <label >Usuário</label>
                        </div>
 
                        <div class="dados">
                        <span class="olho" onclick="mostrarSenha()">
                                <i id="hide1" class="fa-regular fa-eye fa-lg"></i>
                                <i id="hide2" class="fa-regular fa-eye-slash fa-lg"></i>    
                            </span>
                            <input id="senha" name="senha" type="password" placeholder="Digite a sua senha">

                            <label>Senha</label>
                        </div>
                        <div ><a href="forgot-password.php" class="esqueceuSenha"> Esqueceu a Senha?</a></div>

                        <button id="btnLogin" type="submit" name="btnLogin">Entrar</button>

                        <p>Ainda não tem uma conta? <a href="Cadastro.php" class="criarConta">Crie agora</a></p>
                        

                    </form>
                </div>
        </div>
        <script src="../JS/script.js"></script>
        <script src="../JS/login.js"></script>
    </body>

    <?php
        echo footer();
    ?>
</html>
