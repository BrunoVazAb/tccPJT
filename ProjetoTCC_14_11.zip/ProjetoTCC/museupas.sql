-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 14/11/2023 às 02:06
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `museupas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `acervo`
--

CREATE TABLE `acervo` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `imagem` blob DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `artista` varchar(255) DEFAULT NULL,
  `data_criacao` date DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `acervo`
--

INSERT INTO `acervo` (`id`, `nome`, `imagem`, `descricao`, `artista`, `data_criacao`, `categoria`) VALUES
(1, 'monalisa', 0x6d6f6e616c6973612e6a706567, 'é uma pintura feita por Leonardo da vinci', 'leonardo da vici', '2006-10-18', 'pintura'),
(2, 'Noite Estrelada', 0x6e6f6974655f65737472656c6164612e6a706567, 'é uma obra de arte de Van Gogh', 'Van Gogh', '2006-10-18', 'pintura'),
(3, 'Abaporu', 0x616261706f72752e6a706567, 'Abaporu é uma pintura a óleo da artista brasileira Tarsila do Amaral. É uma das principais obras do período antropofágico do movimento modernista no Brasil.', 'TARSILA DO AMARAL', '1928-01-11', 'pintura'),
(4, 'Oprários', 0x4f5045524152494f532e6a706567, 'Operários é um quadro pintado em 1933 por Tarsila do Amaral que representa o processo de industrialização do estado de São Paulo e o imenso número e a variedade étnica das pessoas vindas de todas as ...', 'Tarsila do AMARAL', '1933-10-18', 'pintura'),
(0, 'O Pensador', 0x6f5f70656e7361646f722e77656270, 'É uma das mais famosas esculturas de bronze de todos os tempos', 'Auguste rodin', '1880-11-07', 'escultura'),
(0, ' A Criação de Adão', 0x615f6372696163616f5f64655f6164616f2e6a7067, 'A Criação de Adão é um fresco de 280cm x 570cm,[ pintado por Michelangelo Buonarotti por volta de 1511, que fica no teto da Capela Sistina no Vaticano. ', 'Michelangelo Buonarotti ', '1511-04-29', 'Pintura');

-- --------------------------------------------------------

--
-- Estrutura para tabela `amigos_museu`
--

CREATE TABLE `amigos_museu` (
  `id` int(255) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `code` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `amigos_museu`
--

INSERT INTO `amigos_museu` (`id`, `nome`, `email`, `usuario`, `senha`, `data_hora_cadastro`, `code`) VALUES
(1, 'Ana Silva', 'ana.silva@example.com', 'ana123', '$2y$10$JpSWb76am/BupyOb26j2BuHd2o8vJ86IGcQF60AGfXri1gi7jj1Y.', '2023-08-27 16:55:11', 0),
(2, 'Maria Oliveira', 'maria_oliveira@gmail.com', 'maria_oliveira', '$2y$10$IWM1DZ95rKZMq6bsrEKBQOy6L4d2w4hHgx/2LjkC2rwC4J81uINeW', '2023-08-27 17:02:06', 0),
(3, 'Joao Santos', 'JoaoSantos@gmail.com', 'joao_santos', '$2y$10$mG1.56DuSdVKpFEaj0FcoOXj9ax.gwGixd41FTDPb2Eu9zh3tIcWC', '2023-08-27 17:04:54', 0),
(4, 'Pedro Almeida', 'pedro.almeida@example.com', 'pedro_almeida', '$2y$10$AyvMsGTKF7q.OsWIx6ugWeg0WaNIJZH.n/BPYxODeqBvmQYUIRqSG', '2023-08-27 17:10:40', 0),
(5, 'Sofia Pereira', 'sofia.pereira@example.com', 'sofia_pereira', '$2y$10$Mzo7H3l4bDqWF2wdSfEYRO7vTXdgKJ1EWtxcECACfk9cOMzQxgNj6', '2023-08-27 17:11:11', 0),
(7, 'Carlos da silva', 'carlos@gmail.com', 'carlo', '$2y$10$K.z8mjm2r0gI.RY3oFFBIeNDi7BIvYoWSJsax1Z20oXPmSx7pmzsC', '2023-11-03 17:39:37', 0),
(8, 'Bruno Vaz de Abreu', 'vazs.bruno@gmail.com', 'bhz', '$2y$10$BqnC.vgJgreuo3dD5hmKyuPu9qKRqPu1FLQckr9sAkaHQC6zA3ZEq', '2023-11-12 18:26:19', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `eventos`
--

CREATE TABLE `eventos` (
  `id_administrador` int(11) DEFAULT NULL,
  `id_calendario` int(11) DEFAULT NULL,
  `id_eventos` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_evento` int(11) NOT NULL,
  `data_evento` date DEFAULT NULL,
  `horario_evento` int(11) DEFAULT NULL,
  `descricao_evento` varchar(255) DEFAULT NULL,
  `idamigo_museu` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ingressos_vendidos`
--

CREATE TABLE `ingressos_vendidos` (
  `id_Ingresso` int(11) NOT NULL,
  `data_hora_compra` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `quantidade_total` int(11) DEFAULT NULL,
  `quantidade_ingresso_inteira` int(11) DEFAULT NULL,
  `quantidade_ingresso_meia` int(11) DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` varchar(255) DEFAULT NULL,
  `codigo_ingresso` int(11) DEFAULT NULL,
  `sessao` varchar(255) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `data_escolhida` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `ingressos_vendidos`
--

INSERT INTO `ingressos_vendidos` (`id_Ingresso`, `data_hora_compra`, `quantidade_total`, `quantidade_ingresso_inteira`, `quantidade_ingresso_meia`, `valor_pago`, `forma_pagamento`, `codigo_ingresso`, `sessao`, `id_usuario`, `data_escolhida`) VALUES
(6, '2023-11-12 18:26:35', 2, 2, 0, 100.00, 'Pix', 615840, 'Tarde', 8, NULL),
(7, '2023-11-13 21:40:56', 3, 2, 1, 125.00, 'Pix', 583956, 'Manhã', 8, '2023-11-22');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `amigos_museu`
--
ALTER TABLE `amigos_museu`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id_evento`);

--
-- Índices de tabela `ingressos_vendidos`
--
ALTER TABLE `ingressos_vendidos`
  ADD PRIMARY KEY (`id_Ingresso`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `amigos_museu`
--
ALTER TABLE `amigos_museu`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `ingressos_vendidos`
--
ALTER TABLE `ingressos_vendidos`
  MODIFY `id_Ingresso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `ingressos_vendidos`
--
ALTER TABLE `ingressos_vendidos`
  ADD CONSTRAINT `ingressos_vendidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `amigos_museu` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
