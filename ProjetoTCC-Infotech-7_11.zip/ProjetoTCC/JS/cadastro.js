let nome = document.querySelector('#nome')
let nomeLabel = document.querySelector('#nomeLabel')
let nomeValid = false;

let user = document.querySelector('#user')
let userLabel = document.querySelector('#userLabel')
let userValid = false;


let email = document.querySelector('#email')
let emailLabel = document.querySelector('#emailLabel')
let emailValid = false;

let senha = document.querySelector('#senha')
let senhaLabel = document.querySelector('#senhaLabel')
let senhaValid = false;


let confirmSenha = document.querySelector('#confirmSenha')
let confirmSenhaLabel = document.querySelector('#confirmSenhaLabel')
let confirmSenhaValid = false;

let erro = document.querySelector('#erro')
let sucesso = document.querySelector('#sucesso')

nome.addEventListener('keyup', () => {
    if(nome.value.length <=6){
        nomeLabel.setAttribute('style', 'color: red')
        nomeLabel.innerHTML = 'Nome Completo *Digite no minimo 7 caracteres*'
        nomeValid = false;
    } else{
        nomeLabel.setAttribute('style', 'color: white')
        nomeLabel.innerHTML = 'Nome Completo'
        nomeValid = true;
    }
})

user.addEventListener('keyup', async () => {
    if (user.value.length < 3) {
        userLabel.style.color = 'red';
        userLabel.innerHTML = 'Usuário *Digite no mínimo 3 caracteres*';
        userValid = false;
    } else {
        userLabel.style.color = 'white';
        userLabel.innerHTML = 'Usuário';
        userValid = true;
    }
});

email.addEventListener('keyup', async () => {
    if (!email.checkValidity()) {
        emailLabel.style.color = 'red';
        emailLabel.innerHTML = 'Email *Email inválido*';
        emailValid = false;
    } else {
        emailLabel.style.color = 'white';
        emailLabel.innerHTML = 'Email';
        emailValid = true;
    }
});

senha.addEventListener('keyup', () => {
    if(senha.value.length <=7){
        senhaLabel.setAttribute('style', 'color: red')
        senhaLabel.innerHTML = 'Senha *Digite no minimo 8 caracteres*'
        senhaValid = false;

    } else{
        senhaLabel.setAttribute('style', 'color: white')
        senhaLabel.innerHTML = 'Senha'
        senhaValid = true;

    }

})

confirmSenha.addEventListener('keyup', () => {
    if(senha.value != confirmSenha.value){
        confirmSenhaLabel.setAttribute('style', 'color: red')
        confirmSenhaLabel.innerHTML = 'Confirme a senha *As senhas não são iguais*'
        confirmSenhaValid = false;
        
    } else{
        confirmSenhaLabel.setAttribute('style', 'color: white')
        confirmSenhaLabel.innerHTML = 'Confirme a senha'
        confirmSenhaValid = true;
    }

})

function cadastrar(event){    

        if(nomeValid && userValid && emailValid && senhaValid && confirmSenhaValid ){

        fetch('cadastro.php', {
            method: 'POST',
            body: new FormData(document.querySelector('#form-cadastro')),
        })} else{
            erro.innerHTML = 'Preencha os campos corretamente';
            erro.setAttribute('style', 'display:block');
            erro.innerHTML = 'Preencha os campos corretamente';
            sucesso.setAttribute('style', 'display: none');
            sucesso.innerHTML = '';
            event.preventDefault();
        }
    }
    