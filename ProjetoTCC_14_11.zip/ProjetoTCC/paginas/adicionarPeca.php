<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $nome = $_POST['nome'];
        $imagem = $_POST['imagem'];
        $descricao = $_POST['descricao'];
        $artista = $_POST['artista'];
        $data_criacao = $_POST['data_criacao'];
        $categoria = $_POST['categoria'];
        
        $db = new PDO('mysql:host=localhost;dbname=museupas', 'root', '');
        
        $query = $db->prepare("INSERT INTO acervo (nome, imagem, descricao, artista, data_criacao, categoria) VALUES (?,?,?,?,?,?)");
        
        $query->execute([$nome, $imagem, $descricao, $artista, $data_criacao, $categoria]);

        if (true) {
            header('Location: AcervoADM.php');
        } else {
            echo 'Erro ao adicionar peça ao acervo.';
        }
    }
?>