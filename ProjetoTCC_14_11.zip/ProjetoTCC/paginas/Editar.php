<?php
session_start();

include "conexao.php";

if (isset($_SESSION['id_usuario'])) {
    $idUsuario = $_SESSION['id_usuario'];
    $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
    $resultado_usuario = mysqli_query($conexao, $result_usuario);
    $row_usuario = mysqli_fetch_assoc($resultado_usuario);
}

if (isset($_REQUEST['editar'])) {

    $nome = $_REQUEST['nome'];
    $email = $_REQUEST['email'];
    $usuario = $_REQUEST['usuario'];

    if ((!empty($email)) && (!empty($usuario) && (!empty($nome)))) {

        $id = $_SESSION['id_usuario'];
        $resultado_usuario = mysqli_query($conexao, "UPDATE `amigos_museu` SET `nome`='$nome', `email`='$email',`usuario`='$usuario' WHERE `id`='$id'");

        $_SESSION['sucessoMsg'] = "Perfil editado com sucesso";
        header('location:editar.php');
        exit();
    } else {
        $_SESSION['erroMsg'] = "Preencha os campos corretamente";
        header('location:editar.php');
        exit();
    }
}
if (isset($_REQUEST['apagar'])) {
    $id = $_SESSION['id_usuario'];

    $verificarDependencias = mysqli_query($conexao, "SELECT * FROM ingressos_vendidos WHERE id_usuario = $idUsuario");

    if (mysqli_num_rows($verificarDependencias) > 0) {
        mysqli_query($conexao, "DELETE FROM ingressos_vendidos WHERE id_usuario = $idUsuario");
    }
    
    mysqli_query($conexao, "DELETE FROM amigos_museu WHERE id = $idUsuario");
    


}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/editar.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>

        <nav id="menu-userlog">
            <?php
            include "funcoes.php";
            ?>
        </nav>


    </header>

    <body>

        <nav id="side-menu">
            <ul>
                <li><button onclick="menuShow()" class="btn_icon_header">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button></li><br><br>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>
        </nav>
        <form class="editar">
            <p id="pEditar">Editar Perfil </p>
            <hr>
            <?php
            if (isset($_SESSION['erroMsg'])) :
            ?>
                <div>
                    <p class="erro">Preencha os dados corretamente</p>
                </div>
            <?php
            endif;
            unset($_SESSION['erroMsg']);
            ?>
            
            <?php
                if (isset($_SESSION['sucessoMsg'])) :
            ?>
                <div>
                    <p class="sucesso">Dados Editado com sucesso</p>
                </div>
            <?php
                endif;
                unset($_SESSION['sucessoMsg']);
            ?>
            <div class="box">
                <form action="" method="POST">
                    <div class="dados">
                        <label for="nome">Nome:</label>
                        <input type="text" id="nome" name="nome" placeholder="Digite o nome completo" value="<?php echo $row_usuario['nome']; ?>"><br><br>
                    </div>

                    <div class="dados">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" placeholder="Digite o seu melhor e-mail" value="<?php echo $row_usuario['email']; ?>"><br><br>
                    </div>

                    <div class="dados">
                        <label for="usuario">Usuário:</label>
                        <input type="text" id="usuario" name="usuario" placeholder="Digite o seu novo usuário" value="<?php echo $row_usuario['usuario']; ?>"><br><br>
                    </div>


                    <input type="hidden" name="id" value="<?php echo $row_usuario['id']; ?>">

                    <a href=""><button type="submit" id="salvarAlteracoes" name="editar">Editar</button></a>
                    <a href=""><button type="submit" id="apagarConta" name="apagar">Apagar Conta</button></a>

                </form>
            </div>
        </form>
        <script src="../JS/script.js"></script>
        <script src="../JS/login.js"></script>
    </body>

    <?php
    echo footer();
    ?>

</html>