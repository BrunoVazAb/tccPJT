function atualizarValor() {
  // Obtenha o limite definido pelo usuário
  const limiteTotalIngressos =
    parseInt(document.getElementById("quantidade-ingresso").value) || 0;

  // Obtenha as quantidades selecionadas
  const quantidadeInteira =
    parseInt(document.getElementById("quantidade-ingresso-1").value) || 0;
  const quantidadeMeia =
    parseInt(document.getElementById("quantidade-ingresso-2").value) || 0;

  // Calcule a quantidade máxima permitida para ingressos inteiros
  const limiteIngressoInteira = limiteTotalIngressos - quantidadeMeia;
  if(limiteIngressoInteira > 0){
  if (quantidadeInteira > limiteIngressoInteira) {
    document.getElementById("quantidade-ingresso-1").value = limiteIngressoInteira;
  }
}

  const limiteIngressoMeia = limiteTotalIngressos - quantidadeInteira;
  if(limiteIngressoMeia > 0){
    if (quantidadeMeia > limiteIngressoMeia) {
        document.getElementById("quantidade-ingresso-2").value = limiteIngressoMeia;
      }
  }else
     document.getElementById("quantidade-ingresso-2").value = 0;


  const precoInteira = 50.0;
  const precoMeia = 25.0;

  const valorInteiros = quantidadeInteira * precoInteira;
  const valorMeias = quantidadeMeia * precoMeia;
  const valorTotal = valorInteiros + valorMeias;

  document.getElementById("valor-ingresso-1").textContent =
    "Valor dos Ingressos Inteiros: R$" + valorInteiros.toFixed(2);

  document.getElementById("valor-ingresso-2").textContent =
    "Valor dos Ingressos Meia: R$" + valorMeias.toFixed(2);

  document.getElementById("valor-total").textContent =
    "Valor Total: R$" + valorTotal.toFixed(2);

  document.getElementById("valor_total_input").value = valorTotal;
}
function metodoPagamento()
{
  
  var selectedPaymentMethod = document.getElementById('forma-pagamento').value;

  document.getElementById('campos-cartao').style.display = 'none';
  document.getElementById('qrcode-pix').style.display = 'none';

  if (selectedPaymentMethod === 'Cartão de Crédito') {
      document.getElementById('campos-cartao').style.display = 'block';
      document.getElementById('formCompra').style.marginTop='35%'

      document.getElementById('numero-cartao').required = true;
      document.getElementById('valid-cartao').required = true;
      document.getElementById('CVV-cartao').required = true;
      document.getElementById('nome-cartao').required = true;
      
  } else if (selectedPaymentMethod === 'Pix') {
      document.getElementById('formCompra').style.marginTop='35%'
      document.getElementById('qrcode-pix').style.display = 'block';

      document.getElementById('numero-cartao').required = false;
      document.getElementById('valid-cartao').required = false;
      document.getElementById('CVV-cartao').required = false;
      document.getElementById('nome-cartao').required = false;

  } else if (selectedPaymentMethod === 'Selecione uma opção') {
    document.getElementById('formCompra').style.marginTop='30%'

    document.getElementById('numero-cartao').required = false;
    document.getElementById('valid-cartao').required = false;
    document.getElementById('CVV-cartao').required = false;
    document.getElementById('nome-cartao').required = false;

}
}


function verificarForm() {
  let erro = document.querySelector('#erro');
  let sucesso = document.querySelector('#sucesso');

  var quantidadeIngresso = document.getElementById('quantidade-ingresso').value;
  var quantidadeIngressoInteira = document.getElementById('quantidade-ingresso-1').value;
  var quantidadeIngressoMeia = document.getElementById('quantidade-ingresso-2').value;
  var formaPagamento = document.getElementById('forma-pagamento').value;
  var sessao = document.getElementById('sessao').value;

  if (quantidadeIngresso <= 0 || quantidadeIngressoInteira + quantidadeIngressoMeia < 1 || formaPagamento === 'Selecione uma opção' || sessao === 'Selecione uma opção') {
      erro.innerHTML = 'Preencha os campos corretamente';
      erro.style.display = 'block';
      sucesso.style.display = 'none';
      sucesso.innerHTML = '';
      return false;
  } else {
      erro.innerHTML = '';
      erro.style.display = 'none';
      sucesso.style.display = 'block';
      sucesso.innerHTML = 'Compra Realizada com sucesso';

      setTimeout(() => {
        return true;
      }, 4000)

 }
}
