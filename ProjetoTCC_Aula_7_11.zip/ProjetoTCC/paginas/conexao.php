<?php
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "museupas";

    $conexao = mysqli_connect($host, $user, $password, $database);

    if (!$conexao) {
        die("Conexão falhou: " . mysqli_connect_error());
    }
?>