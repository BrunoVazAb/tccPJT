<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', '1');
include "conexao.php";
include "funcoes.php";

if (isset($_SESSION['id_usuario'])) {
    $idUsuario = $_SESSION['id_usuario'];
    $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
    $resultado_usuario = mysqli_query($conexao, $result_usuario);
    $row_usuario = mysqli_fetch_assoc($resultado_usuario);
}

if (!isset($_SESSION['usuario'])) {
    header("Location: Login.php");
    $_SESSION['tentativa_acesso_compra'] = true;

    exit();
}

$btnCompraIngresso = filter_input(INPUT_POST, 'btnCompraIngresso');
if ($btnCompraIngresso) {
    // Coleta os dados do formulário
    $quantidadeTotal = $_POST['quantidade-ingresso'];
    $quantidadeIngressoInteira = $_POST['quantidade-ingresso-1'];
    $quantidadeIngressoMeia = $_POST['quantidade-ingresso-2'];
    $valorTotal = $_POST['valor_total_input'];
    $formaPagamento = $_POST['forma_pagamento'];
    $sessao = $_POST['sessao'];

    $codigoIngresso = mt_rand(100000, 999999);

    $idUsuario = $_SESSION['id_usuario'];

    echo $quantidadeTotal;
    echo $quantidadeIngressoInteira;
    echo $quantidadeIngressoMeia;
    $sql = "INSERT INTO ingressos_vendidos (data_hora_compra, quantidade_total, quantidade_ingresso_inteira, quantidade_ingresso_meia, valor_pago, forma_pagamento, codigo_ingresso, sessao, id_usuario)
            VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ddddsssi", $quantidadeTotal, $quantidadeIngressoInteira, $quantidadeIngressoMeia, $valorTotal, $formaPagamento, $codigoIngresso, $sessao, $idUsuario);

    if ($stmt->execute()) {
        echo "Ingresso comprado com sucesso!";
    } else {
        echo "Erro ao comprar o ingresso: " . $stmt->error;
    }

    $stmt->close();
    $conexao->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../CSS/styles.css">
    <link rel="stylesheet" href="../CSS/compraIngresso.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>

        <nav id="menu-userlog">
            <?php
            usuarioLogado()
            ?>
        </nav>
        <div id="blur-background"></div>
        <div id="popup">
            <h1>Editar Perfil</h1>
            <?php

            $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
            $nome = filter_input(INPUT_POST, 'nome', );
            $usuario = filter_input(INPUT_POST, 'usuario', );
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

            $result_usuario = "UPDATE amigos_museu SET nome='$nome', email='$email',usuario='$usuario' WHERE id='$id'";
            $resultado_usuario = mysqli_query($conexao, $result_usuario);

            if (isset($_SESSION['id_usuario'])) {
                $idUsuario = $_SESSION['id_usuario'];
                $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
                $resultado_usuario = mysqli_query($conexao, $result_usuario);
                $row_usuario = mysqli_fetch_assoc($resultado_usuario);
            }

            if (mysqli_affected_rows($conexao)) {
                $_SESSION['msg'] = "<p style='color:green;'>Usuário editado com sucesso</p>";
            }
            ?>

            <form id="formEditarPerfil" method="POST" action="">
                <input type="hidden" name="id" value="<?php echo $row_usuario['id']; ?>">


                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Digite o nome completo" value="<?php echo $row_usuario['nome']; ?>"><br><br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Digite o seu melhor e-mail" value="<?php echo $row_usuario['email']; ?>"><br><br>

                <label for="usuario">Usuário:</label>
                <input type="text" id="usuario" name="usuario" placeholder="Digite o seu novo usuário" value="<?php echo $row_usuario['usuario']; ?>"><br><br>

                <a href=""><button type="button" id="salvarAlteracoes">Salvar Alterações</button></a>
                <span id="fecharPopup"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAABJUlEQVR4nO3YT0sCQRyH8YeuUu0KG/RHUG8efAceetFBJ6noEKUI6iG1wHolxcIYg6wi67Qzs3w/IHga92F09zeCiIiIiMg/6QEPwKXDNRvAHXBLhYbADzAHLhysdwo8W2ueUJEMmJoPfj9yZ/KdeDRrfQNdKpYCY3MBC+DKQUQHT46JsSO+fEYUxSwPjMkjnkKKsGNGVsw1u50BLyFGFMWsdsQEH7GR7Ik534poE7hkK+YmxoiNJjAxF/4BvJr3n0CLyCTAmwnIX+uYdqJ2Ic06fLWSgjtXdD/2dM/tN5pnSHrA0z3Y0aTMvBVsTFpiAg5mfHc9xnuNyaxT4qLkKbFhzv7eTocZMHN41PUWM6zLnw99E+Miwo65BwYO1xQRERER4c8v6Th7MMbV15kAAAAASUVORK5CYII="></span>
            </form>

        </div>
    </header>

    <nav id="side-menu">
        <ul>
            <li><button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button></li> <br><br>
            <li><a href="paginas/historia.php">História</a></li>
            <li><a href="paginas/Acervo.php">Acervo Online</a></li>
            <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
            <li><a href="paginas/Bilheteria.php">Eventos</a></li>
        </ul>
    </nav>

    <div id="formCompra">
        <h1>Compra de Ingressos</h1>
        <form id="compra-ingresso" name="comprar-ingresso" method="POST" action="">
            <div name="erro" id="erro"></div>
            <div name="sucesso" id="sucesso"></div>

            <div id="ingressos">
                <label for="quantidade-ingresso">Quantidade Total de Ingressos:</label>
                <input type="number" id="quantidade-ingresso" min="1" name="quantidade-ingresso" value="1" onchange="atualizarValor()">
            </div>

            <div id="ingressos">
                <div>
                    <label for="quantidade-ingresso-1">Quantidade de Ingressos Inteiros (R$50,00):</label>
                    <input type="number" id="quantidade-ingresso-1" min="0" "quantidade-ingresso-1" value="0" onchange="atualizarValor()">
                    <div id="valor-ingresso-1" style="display:none">Valor dos Ingressos Inteiros: R$0.00</div>
                </div>
                <div id="ingressos">

                    <div>
                        <label for="quantidade-ingresso-2">Quantidade de Meia-entrada (R$25,00):</label>
                        <input type="number" id="quantidade-ingresso-2" min='0' name="quantidade-ingresso-2" value="0" onchange="atualizarValor()">
                        <div id="valor-ingresso-2" style="display:none">Valor dos Ingressos Meia:: R$0.00</div>
                    </div>
                </div>

            </div>

            <div id="ingressos">
                <label for="sessao">Selecione a Sessão:</label>
                <select id="sessao" name="sessao">
                    <option value=""> Selecione uma opção </option>
                    <option value="Manhã">Manhã</option>
                    <option value="Tarde">Tarde</option>
                    <option value="Noite">Noite</option>
                    <!-- Adicione mais opções de sessão conforme necessário -->
                </select>
            </div>
            <div id="valor-total">Valor Total: R$0.00</div>
                <input type="hidden" name="valor_total_input" id="valor_total_input">
<hr>


            <div id="ingressos">
                <label for="forma-pagamento">Forma de Pagamento:</label>
                <select id="forma-pagamento" name="forma_pagamento">
                    <option value=""> Selecione uma opção </option>
                    <option value="Boleto"> Boleto </option>
                    <option value="Pix"> Pix </option>
                    <option value="Cartão de Crédito">Cartão de Crédito</option>
                    <option value="Cartão de Débito">Cartão de Débito</option>
                </select>
            </div>
            <input type="submit" onclick="verificarForm()" name="btnCompraIngresso" id="btnCompraIngresso" value="Comprar Ingresso"></input>

    </div>
    </div>
    </form>
    </div>
    <script src="../JS/script.js"></script>
    <script src="../JS/compraIngressos.js"></script>
</body>

<?php
echo footer();
?>

</html>