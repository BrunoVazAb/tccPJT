<?php
session_start();
include "conexao.php";
include "funcoes.php";

if (isset($_SESSION['id_usuario'])) {
    $idUsuario = $_SESSION['id_usuario'];
    $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
    $resultado_usuario = mysqli_query($conexao, $result_usuario);
    $row_usuario = mysqli_fetch_assoc($resultado_usuario);
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.css" />
   
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bilheteria.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>

        <nav id="menu-userlog">
            <?php
            usuarioLogado()
            ?>
        </nav>
    </header>

    <nav id="side-menu">
        <ul>
            <li><button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button></li> <br><br>
            <li><a href="paginas/historia.php">História</a></li>
            <li><a href="paginas/Acervo.php">Acervo Online</a></li>
            <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
            <li><a href="paginas/Bilheteria.php">Eventos</a></li>
        </ul>
    </nav>

    <div class="wrapper">
        <div class="eventosTitle">
            <h1>
                Nossos Proximos Eventos
            </h1>
        </div>

        <div class="item-bg"></div>
        <div class="event-slider">
            <div class="event-slider__wrp swiper-wrapper">
                <div class="event-slider__item swiper-slide">
                    <a href="./compraIngressos.php" class="event__item">
                        <div class="event-date">
                            <span class="event-date__title">24</span>
                            <span class="event-date__txt">Nov</span>
                        </div>
                        <div class="event__title">
                            Pinturas a óleo
                        </div>

                        <p class="event__txt">Participe de uma jornada onde a magia da pintura a óleo ganha vida! Em nosso evento de pintura a óleo, você terá a oportunidade de explorar as obras-primas da arte enquanto cria sua própria obra inspirada pelos grandes mestres.</p>

                        <div class="event__img">
                            <img src="../imagens/eventos/pinturaOleo.jpg" alt="Imagem 1" />
                        </div>
                    </a>
                </div>

                <div class="event-slider__item swiper-slide">
                    <a href="./compraIngressos.php" class="event__item">
                        <div class="event-date">
                            <span class="event-date__title">15</span>
                            <span class="event-date__txt">Dez</span>
                        </div>
                        <div class="event__title">
                            Escultura em Argila
                        </div>

                        <p class="event__txt">Junte-se a nós em um evento de escultura onde a argila se transforma em esculturas fascinantes. Com as dicas de um mestre ceramista, você aprenderá todas as técnicas necessárias para criar sua própria peça única. </p>

                        <div class="event__img">
                            <img src="../imagens/eventos/esculturaArgila.jpg" alt="Imagem 1" />
                        </div>
                    </a>
                </div>

                <div class="event-slider__item swiper-slide">
                    <a href="./compraIngressos.php" class="event__item">
                        <div class="event-date">
                            <span class="event-date__title">5</span>
                            <span class="event-date__txt">Jan</span>
                        </div>
                        <div class="event__title">Arte Contemporânea </div>

                        <p class="event__txt"> Junte-se a nós em uma noite dedicada à arte contemporânea. Experimente o que há de mais inovador e emocionante na cena artística atual, com exposições exclusivas de artistas renomados. </p>

                        <div class="event__img">
                            <img src="../imagens/eventos/arteComtemporanea.jpg" alt="Imagem 1" />
                        </div>
                    </a>
                </div>

                <div class="event-slider__item swiper-slide">
                    <a href="./compraIngressos.php" class="event__item">
                        <div class="event-date">
                            <span class="event-date__title">26</span>
                            <span class="event-date__txt">Jan</span>
                        </div>
                        <div class="event__title">
                            Arte Abstrata
                        </div>


                        <p class="event__txt">
                            Mergulhe em um mundo de abstração, venha apreciar as artes de nossos artistas contemporâneos que desafiam as fronteiras da interpretação. Uma oportunidade de explorar a arte de uma maneira totalmente nova.</p>

                        <div class="event__img">
                            <img src="../imagens/eventos/arteAbstrata.jpg" alt="Imagem 1" />
                        </div>
                    </a>
                </div>

            </div>

            <div class="event-slider__ctr">

                <div class="event-slider__arrows">
                    <button class="event-slider__arrow event-slider-prev">
                        <span class="icon-font">
                            <svg class="icon icon-arrow-left">
                                <use xlink:href="#icon-arrow-left"></use>
                            </svg>
                        </span>
                    </button>
                    <button class="event-slider__arrow event-slider-next">
                        <span class="icon-font">
                            <svg class="icon icon-arrow-right">
                                <use xlink:href="#icon-arrow-right"></use>
                            </svg>
                        </span>
                    </button>
                </div>
                <div class="event-slider__pagination"></div>
            </div>
        </div>
    </div>
    <svg hidden="hidden">
        <defs>
            <symbol id="icon-arrow-left" width="299" height="39" viewBox="0 0 32 32" >
                <title>arrow-left</title>
                <path d="M0.704 17.696l9.856 9.856c0.896 0.896 2.432 0.896 3.328 0s0.896-2.432 0-3.328l-5.792-5.856h21.568c1.312 0 2.368-1.056 2.368-2.368s-1.056-2.368-2.368-2.368h-21.568l5.824-5.824c0.896-0.896 0.896-2.432 0-3.328-0.48-0.48-1.088-0.704-1.696-0.704s-1.216 0.224-1.696 0.704l-9.824 9.824c-0.448 0.448-0.704 1.056-0.704 1.696s0.224 1.248 0.704 1.696z"></path>
            </symbol>
            <symbol id="icon-arrow-right" width="299" height="39" viewBox="0 0 32 32">
                <title>arrow-right</title>
                <path d="M31.296 14.336l-9.888-9.888c-0.896-0.896-2.432-0.896-3.328 0s-0.896 2.432 0 3.328l5.824 5.856h-21.536c-1.312 0-2.368 1.056-2.368 2.368s1.056 2.368 2.368 2.368h21.568l-5.856 5.824c-0.896 0.896-0.896 2.432 0 3.328 0.48 0.48 1.088 0.704 1.696 0.704s1.216-0.224 1.696-0.704l9.824-9.824c0.448-0.448 0.704-1.056 0.704-1.696s-0.224-1.248-0.704-1.664z"></path>
            </symbol>
        </defs>
    </svg>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
    <script src="../JS/script.js"></script>
    <script src="../JS/bilheteria.js"></script>



<?php
    echo footer();
?>

</html>