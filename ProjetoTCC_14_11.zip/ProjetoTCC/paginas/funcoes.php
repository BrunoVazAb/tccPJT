<?php
    function usuarioLogado(){
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    $usuarioLogado = isset($_SESSION['usuario']);

    $currentURL = $_SERVER['REQUEST_URI'];

    if ($usuarioLogado) {
        if (basename($_SERVER['PHP_SELF']) === 'index.php') {
            echo '<a href="paginas/Editar.php" style="cursor: pointer;"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAACtUlEQVR4nO2aTWsTYRDHR4TiWVHwpeKH0JMHRU+CFq/iXdTWehQRPPgNFA++oSYzMZCDeKn24M2XT1Dw3WLNzNqZtLWmYNHKyrPpoWJpk+yuedY8PxhY8kL2z392ZnY2AIFAIBDoc2a5tHua8ZwJjqvQa2NacJEcC443uDwyU68OQtFpTN3faYI3lXHJhOK1Qpl+GWMtiqp7oIgYl48bY3M9oasI/2Z1HIIioYznE8c6FLvSbWUahaI4qynE/pHivjvd+Iy7uknjNdP704Md4CsmdDcrsSviNvjaerSNaty5y7jkMgd8Q5lGc3C3FRENg28Y05PcBDOOgW+Y0Lu8BLuJDHzDMqzOqzjcBN+wvMQuB/iG9Z1gzi+llWkefMOE3uRXtPAV+Ib1W1tqcHkkv2u4cgZ8Y6ZeHcxptPzp5WjpMME7ORSsG+DzSkfdLV2G1VkVt4PPqNCRLFK7tQCoHIMioEyjaVc8bssJRcLqONRNeidpHNFRKCIita0meNVV2nZcVcay99ds27uuiIaN8bGbmpIxlLG5fDxmgme9bT2BQCAQ+B+I49pGE9xnUjllQtdU6Gnr2TB+MaHvSTBF7jX3nuvXrc+W9rrvQhGIovI211NV8JEKzXU9WgrOqtBDEzrthhfwiXiiNmBcOek2Hu1MVN3cDycDC+MJ91s9EzpfL21RwUvGJFmLXMN5bjBd/DpV2/zPhMYTtYHkgXeKlE0vnOaMKxcmJ+9tylWsSuWAMX3sldC/gvH9NNP+zIXGcbzBmK7ksbPK4BpfUsHL7hwzE6uM13stbP3AW5mInk7+X9VrMe2FWxWnFmyMH3otpAOX36YXLMlUFBcimBZSC1bBlwVy+Fl6h6PyoTwmqKxDmX64tplasMPqeNiEXpjgooeuLprgc4vwYHKygUAgEAgEwFd+AyUL71s8LU7gAAAAAElFTkSuQmCC">
            </a>';
            echo '<a  href="paginas/logout.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAABd0lEQVR4nO3asU7DMBAGYMPAigQrL4J4MEa6lMJjoLtKKA/AgniADgGGbmyQOwmfqeAJggzNgGgju1Xp2fiXPFryp0sT2z3TTqs9y3AphCyMrYZhGcgyjvzaTGgsw8W2F94DOo+BkJ/01oyPjZK8Ep50lQme1OmNskjsugpkw5FSEWWRUhFlERqfZvHW8hGCgckBEpUC2WCE4VoIbmazaj/pR0sY66+9FsEkGKMR4l7gSBif5mur35+rgyQhK2G0Qn5j4L4XoxkShdEOWYT5aK4OTYqQIEwqkAWYhx+YlCC9mNQgSzHrQNq23RHGx21fGwljvSbkbNf/8JKHZPNoqXoNS0IQ1/ctSQXicvggupD9lnaIC93Oa4a4mDOJVojL4WDlcjnqWoJpFpcPlvDOMtwmfx20UgrkDyI5XGILwSBqXWohXP7V1RUpFVEW+bcVsfOmGt/IYtQ11WATPMn3RSm4zlk2hsGQ78YzHHWV0TB8JTwipvHsE1rmBtGXmzotAAAAAElFTkSuQmCC"></a>';
        } else {
            echo '<a href="Editar.php" style="cursor: pointer;"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAACtUlEQVR4nO2aTWsTYRDHR4TiWVHwpeKH0JMHRU+CFq/iXdTWehQRPPgNFA++oSYzMZCDeKn24M2XT1Dw3WLNzNqZtLWmYNHKyrPpoWJpk+yuedY8PxhY8kL2z392ZnY2AIFAIBDoc2a5tHua8ZwJjqvQa2NacJEcC443uDwyU68OQtFpTN3faYI3lXHJhOK1Qpl+GWMtiqp7oIgYl48bY3M9oasI/2Z1HIIioYznE8c6FLvSbWUahaI4qynE/pHivjvd+Iy7uknjNdP704Md4CsmdDcrsSviNvjaerSNaty5y7jkMgd8Q5lGc3C3FRENg28Y05PcBDOOgW+Y0Lu8BLuJDHzDMqzOqzjcBN+wvMQuB/iG9Z1gzi+llWkefMOE3uRXtPAV+Ib1W1tqcHkkv2u4cgZ8Y6ZeHcxptPzp5WjpMME7ORSsG+DzSkfdLV2G1VkVt4PPqNCRLFK7tQCoHIMioEyjaVc8bssJRcLqONRNeidpHNFRKCIita0meNVV2nZcVcay99ds27uuiIaN8bGbmpIxlLG5fDxmgme9bT2BQCAQ+B+I49pGE9xnUjllQtdU6Gnr2TB+MaHvSTBF7jX3nuvXrc+W9rrvQhGIovI211NV8JEKzXU9WgrOqtBDEzrthhfwiXiiNmBcOek2Hu1MVN3cDycDC+MJ91s9EzpfL21RwUvGJFmLXMN5bjBd/DpV2/zPhMYTtYHkgXeKlE0vnOaMKxcmJ+9tylWsSuWAMX3sldC/gvH9NNP+zIXGcbzBmK7ksbPK4BpfUsHL7hwzE6uM13stbP3AW5mInk7+X9VrMe2FWxWnFmyMH3otpAOX36YXLMlUFBcimBZSC1bBlwVy+Fl6h6PyoTwmqKxDmX64tplasMPqeNiEXpjgooeuLprgc4vwYHKygUAgEAgEwFd+AyUL71s8LU7gAAAAAElFTkSuQmCC">
            </a>';
            echo '<a href="logout.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAABd0lEQVR4nO3asU7DMBAGYMPAigQrL4J4MEa6lMJjoLtKKA/AgniADgGGbmyQOwmfqeAJggzNgGgju1Xp2fiXPFryp0sT2z3TTqs9y3AphCyMrYZhGcgyjvzaTGgsw8W2F94DOo+BkJ/01oyPjZK8Ep50lQme1OmNskjsugpkw5FSEWWRUhFlERqfZvHW8hGCgckBEpUC2WCE4VoIbmazaj/pR0sY66+9FsEkGKMR4l7gSBif5mur35+rgyQhK2G0Qn5j4L4XoxkShdEOWYT5aK4OTYqQIEwqkAWYhx+YlCC9mNQgSzHrQNq23RHGx21fGwljvSbkbNf/8JKHZPNoqXoNS0IQ1/ctSQXicvggupD9lnaIC93Oa4a4mDOJVojL4WDlcjnqWoJpFpcPlvDOMtwmfx20UgrkDyI5XGILwSBqXWohXP7V1RUpFVEW+bcVsfOmGt/IYtQ11WATPMn3RSm4zlk2hsGQ78YzHHWV0TB8JTwipvHsE1rmBtGXmzotAAAAAElFTkSuQmCC"></a>';
        }
    } else {
        if ( strpos($currentURL, '/index.php')) {
            echo '<ul>
                <a href="./paginas/Login.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAACtUlEQVR4nO2aTWsTYRDHR4TiWVHwpeKH0JMHRU+CFq/iXdTWehQRPPgNFA++oSYzMZCDeKn24M2XT1Dw3WLNzNqZtLWmYNHKyrPpoWJpk+yuedY8PxhY8kL2z392ZnY2AIFAIBDoc2a5tHua8ZwJjqvQa2NacJEcC443uDwyU68OQtFpTN3faYI3lXHJhOK1Qpl+GWMtiqp7oIgYl48bY3M9oasI/2Z1HIIioYznE8c6FLvSbWUahaI4qynE/pHivjvd+Iy7uknjNdP704Md4CsmdDcrsSviNvjaerSNaty5y7jkMgd8Q5lGc3C3FRENg28Y05PcBDOOgW+Y0Lu8BLuJDHzDMqzOqzjcBN+wvMQuB/iG9Z1gzi+llWkefMOE3uRXtPAV+Ib1W1tqcHkkv2u4cgZ8Y6ZeHcxptPzp5WjpMME7ORSsG+DzSkfdLV2G1VkVt4PPqNCRLFK7tQCoHIMioEyjaVc8bssJRcLqONRNeidpHNFRKCIita0meNVV2nZcVcay99ds27uuiIaN8bGbmpIxlLG5fDxmgme9bT2BQCAQ+B+I49pGE9xnUjllQtdU6Gnr2TB+MaHvSTBF7jX3nuvXrc+W9rrvQhGIovI211NV8JEKzXU9WgrOqtBDEzrthhfwiXiiNmBcOek2Hu1MVN3cDycDC+MJ91s9EzpfL21RwUvGJFmLXMN5bjBd/DpV2/zPhMYTtYHkgXeKlE0vnOaMKxcmJ+9tylWsSuWAMX3sldC/gvH9NNP+zIXGcbzBmK7ksbPK4BpfUsHL7hwzE6uM13stbP3AW5mInk7+X9VrMe2FWxWnFmyMH3otpAOX36YXLMlUFBcimBZSC1bBlwVy+Fl6h6PyoTwmqKxDmX64tplasMPqeNiEXpjgooeuLprgc4vwYHKygUAgEAgEwFd+AyUL71s8LU7gAAAAAElFTkSuQmCC">
                </a> 
                </ul>';
        } else{
            echo '<ul>
                <a href=" Login.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAACtUlEQVR4nO2aTWsTYRDHR4TiWVHwpeKH0JMHRU+CFq/iXdTWehQRPPgNFA++oSYzMZCDeKn24M2XT1Dw3WLNzNqZtLWmYNHKyrPpoWJpk+yuedY8PxhY8kL2z392ZnY2AIFAIBDoc2a5tHua8ZwJjqvQa2NacJEcC443uDwyU68OQtFpTN3faYI3lXHJhOK1Qpl+GWMtiqp7oIgYl48bY3M9oasI/2Z1HIIioYznE8c6FLvSbWUahaI4qynE/pHivjvd+Iy7uknjNdP704Md4CsmdDcrsSviNvjaerSNaty5y7jkMgd8Q5lGc3C3FRENg28Y05PcBDOOgW+Y0Lu8BLuJDHzDMqzOqzjcBN+wvMQuB/iG9Z1gzi+llWkefMOE3uRXtPAV+Ib1W1tqcHkkv2u4cgZ8Y6ZeHcxptPzp5WjpMME7ORSsG+DzSkfdLV2G1VkVt4PPqNCRLFK7tQCoHIMioEyjaVc8bssJRcLqONRNeidpHNFRKCIita0meNVV2nZcVcay99ds27uuiIaN8bGbmpIxlLG5fDxmgme9bT2BQCAQ+B+I49pGE9xnUjllQtdU6Gnr2TB+MaHvSTBF7jX3nuvXrc+W9rrvQhGIovI211NV8JEKzXU9WgrOqtBDEzrthhfwiXiiNmBcOek2Hu1MVN3cDycDC+MJ91s9EzpfL21RwUvGJFmLXMN5bjBd/DpV2/zPhMYTtYHkgXeKlE0vnOaMKxcmJ+9tylWsSuWAMX3sldC/gvH9NNP+zIXGcbzBmK7ksbPK4BpfUsHL7hwzE6uM13stbP3AW5mInk7+X9VrMe2FWxWnFmyMH3otpAOX36YXLMlUFBcimBZSC1bBlwVy+Fl6h6PyoTwmqKxDmX64tplasMPqeNiEXpjgooeuLprgc4vwYHKygUAgEAgEwFd+AyUL71s8LU7gAAAAAElFTkSuQmCC">
                </a> 
                </ul>';
        }

    }
    }

    function footer(){
      echo '    <footer>
                    <div id="footer_content">
                        <div id="footer_contacts">
                            <h1>Conecte-se conosco </h1>
                
                            <div id="footer_social_media">
                                <a href="https://www.instagram.com/museupauloagostinhosobrinho/" class="footer-link" id="instagram">
                                    <i class="fa-brands fa-instagram"></i>
                                </a>
                                <a href="#" class="footer-link" id="youtube">
                                    <i class="fa-brands fa-youtube"></i>
                                </a>                
                                <a href="#" class="footer-link" id="twitter">
                                    <i class="fa-brands fa-twitter" ></i>
                                </a>
                            </div>
                
                        </div>
                        <ul class="footer-list">
                            <li>
                                <h3> Blog </h3>
                            </li>
                            <li>
                                <a href="../index.php" class="footer-link"> Home</a>
                            </li>
                            <li>
                                <a href="Desenvolvedores.php" class="footer-link"> Sobre nós</a>
                            </li>            
                
                        </ul>
                
                        <ul class="footer-list">
                            <li>
                                <h3> Produtos </h3>
                            </li>
                            <li>
                                <a href="#" class="footer-link"> App</a>
                            </li>
                            <li>
                                <a href="#" class="footer-link"> Desktop</a>
                
                        </ul>
                        <div id="footer_subscribe">
                            <h3> Venha nos Visitar</h3>
                            <p>
                                Rua: General. Telles, 1040 - Centro, Botucatu - SP, 18600-030                </p>
                            <a class="footer-link" href="https://www.google.com.br/maps/place/Pinacoteca+Forum+das+Artes/@-22.7822779,-48.5395706,10z/data=!4m10!1m2!2m1!1smuseu+interior+sp!3m6!1s0x94c6df7a0673d385:0x3132e2d227232cfe!8m2!3d-22.8873312!4d-48.4441729!15sChFtdXNldSBpbnRlcmlvciBzcFoTIhFtdXNldSBpbnRlcmlvciBzcJIBBm11c2V1bZoBJENoZERTVWhOTUc5blMwVkpRMEZuU1VSS2FWazNVV3RCUlJBQuABAA!16s%2Fg%2F11cp7f3z2m?entry=ttu">Ver no mapa</a>
                        </div>
                    </div>
                    <div id="footer_copyright">
                        &#169
                        2023 Todos os direitos reservados
                    </div>
                </footer>';
    }
    function footerIndex(){
        echo '    <footer>
                      <div id="footer_content">
                          <div id="footer_contacts">
                              <h1>Conecte-se conosco </h1>
                  
                              <div id="footer_social_media">
                                  <a href="https://www.instagram.com/museupauloagostinhosobrinho/" class="footer-link" id="instagram">
                                      <i class="fa-brands fa-instagram"></i>
                                  </a>
                                  <a href="#" class="footer-link" id="youtube">
                                      <i class="fa-brands fa-youtube"></i>
                                  </a>                
                                  <a href="#" class="footer-link" id="twitter">
                                      <i class="fa-brands fa-twitter" ></i>
                                  </a>
                              </div>
                  
                          </div>
                          <ul class="footer-list">
                              <li>
                                  <h3> Blog </h3>
                              </li>
                              <li>
                                  <a href="#" class="footer-link"> Home</a>
                              </li>
                              <li>
                                  <a href="paginas/Desenvolvedores.php" class="footer-link"> Sobre nós</a>
                              </li>            
                  
                          </ul>
                  
                          <ul class="footer-list">
                              <li>
                                  <h3> Produtos </h3>
                              </li>
                              <li>
                                  <a href="#" class="footer-link"> App</a>
                              </li>
                              <li>
                                  <a href="#" class="footer-link"> Desktop</a>
                  
                          </ul>
                          <div id="footer_subscribe">
                              <h3> Venha nos Visitar</h3>
                              <p>
                                  Rua: General. Telles, 1040 - Centro, Botucatu - SP, 18600-030                </p>
                              <a class="footer-link" href="https://www.google.com.br/maps/place/Pinacoteca+Forum+das+Artes/@-22.7822779,-48.5395706,10z/data=!4m10!1m2!2m1!1smuseu+interior+sp!3m6!1s0x94c6df7a0673d385:0x3132e2d227232cfe!8m2!3d-22.8873312!4d-48.4441729!15sChFtdXNldSBpbnRlcmlvciBzcFoTIhFtdXNldSBpbnRlcmlvciBzcJIBBm11c2V1bZoBJENoZERTVWhOTUc5blMwVkpRMEZuU1VSS2FWazNVV3RCUlJBQuABAA!16s%2Fg%2F11cp7f3z2m?entry=ttu">Ver no mapa</a>
                          </div>
                      </div>
                      <div id="footer_copyright">
                          &#169
                          2023 Todos os direitos reservados
                      </div>
                  </footer>';
      }
?>


