function mostrarSenha() {
    var senha = document.getElementById('senha');
    var hide1 = document.getElementById('hide1');
    var hide2 = document.getElementById('hide2');

    if(senha.type === 'password'){
        senha.type = "text";
        hide1.style.display = "block";
        hide2.style.display = "none";
    }else{
        senha.type = "password";
        hide1.style.display = "none";
        hide2.style.display = "block";
    }
}