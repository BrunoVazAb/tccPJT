-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/08/2023 às 19:14
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `museupas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `amigos_museu`
--

CREATE TABLE `amigos_museu` (
  `id` int(255) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `amigos_museu`
--

INSERT INTO `amigos_museu` (`id`, `nome`, `email`, `usuario`, `senha`, `data_hora_cadastro`) VALUES
(1, 'Ana Silva', 'ana.silva@example.com', 'ana123', '$2y$10$JpSWb76am/BupyOb26j2BuHd2o8vJ86IGcQF60AGfXri1gi7jj1Y.', '2023-08-27 16:55:11'),
(2, 'João Santos', 'joao.santos@example.com', 'joao_santos', '$2y$10$IWM1DZ95rKZMq6bsrEKBQOy6L4d2w4hHgx/2LjkC2rwC4J81uINeW', '2023-08-27 17:02:06'),
(3, 'Maria Oliveira', 'maria.oliveira@example.com', 'maria_oliveira', '$2y$10$mG1.56DuSdVKpFEaj0FcoOXj9ax.gwGixd41FTDPb2Eu9zh3tIcWC', '2023-08-27 17:04:54'),
(4, 'Pedro Almeida', 'pedro.almeida@example.com', 'pedro_almeida', '$2y$10$AyvMsGTKF7q.OsWIx6ugWeg0WaNIJZH.n/BPYxODeqBvmQYUIRqSG', '2023-08-27 17:10:40'),
(5, 'Sofia Pereira', 'sofia.pereira@example.com', 'sofia_pereira', '$2y$10$Mzo7H3l4bDqWF2wdSfEYRO7vTXdgKJ1EWtxcECACfk9cOMzQxgNj6', '2023-08-27 17:11:11');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `amigos_museu`
--
ALTER TABLE `amigos_museu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `amigos_museu`
--
ALTER TABLE `amigos_museu`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
