<?php
session_start();
include 'funcoes.php';
ob_start();
$btnCadUsuario = filter_input(INPUT_POST, 'btnCadUsuario');

if ($btnCadUsuario) {

    include_once 'conexao.php';
    $dados_rc = filter_input_array(INPUT_POST, FILTER_DEFAULT);
    $erro = false;

    $dados_st = array_map('strip_tags', $dados_rc);
    $dados = array_map('trim', $dados_st);

    if (in_array('', $dados)) {
        $erro = true;
    } else {
        $result_usuario = "SELECT id FROM amigos_museu WHERE usuario='" . $dados['usuario'] . "'";
        $resultado_usuario = mysqli_query($conexao, $result_usuario);
        if (($resultado_usuario) and ($resultado_usuario->num_rows != 0)) {
            $erro = true;
            $_SESSION['msg'] = "<p style='text-align: center; color: white; background-color: rgb(255, 38, 38); padding: 1vh; border-radius: 0.4vh;'>Este usuário já está sendo utilizado</p>";
        }

        $result_usuario = "SELECT id FROM amigos_museu WHERE email='" . $dados['email'] . "'";
        $resultado_usuario = mysqli_query($conexao, $result_usuario);
        if (($resultado_usuario) and ($resultado_usuario->num_rows != 0)) {
            $erro = true;
            $_SESSION['msg'] = "<p style='text-align: center; color: white; background-color: rgb(255, 38, 38); padding: 1vh; border-radius: 0.4vh;'>Este e-mail já está cadastrado</p>";
        }
    }

    if (!$erro) {
        $dados['senha'] = password_hash($dados['senha'], PASSWORD_DEFAULT);

        $result_usuario = "INSERT INTO amigos_museu (nome, email, usuario, senha) VALUES (
                        '" . $dados['nome'] . "',
                        '" . $dados['email'] . "',
                        '" . $dados['usuario'] . "',
                        '" . $dados['senha'] . "'
                        )";
        $resultado_usuario = mysqli_query($conexao, $result_usuario);
        if (mysqli_insert_id($conexao)) {
            $_SESSION['msg'] = "<p style='text-align: center; color: white;background-color:rgb(4, 196, 4); padding: 1vh; border-radius: 0.4vh;'>Usuário cadastrado com sucesso</p>";

            sleep(1);
            header("Location: Login.php");
        } else {
            $_SESSION['msg'] = "<p style='text-align: center; color: white; background-color: rgb(255, 38, 38); padding: 1vh; border-radius: 0.4vh;'>Erro ao cadastrar o usuário</p>";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    include('conexao.php');

    if (isset($_POST['usuario']) && isset($_POST['senha']) && !empty($_POST['usuario']) && !empty($_POST['senha'])) {
        $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
        $senhaDigitada = $_POST['senha'];
        $query = "SELECT id, senha FROM amigos_museu WHERE usuario = '{$usuario}'";
        $result = mysqli_query($conexao, $query);
        $row = mysqli_fetch_assoc($result);

        if ($row && password_verify($senhaDigitada, $row['senha'])) {
            $_SESSION['usuario'] = $usuario;
            $_SESSION['id_usuario'] = $row['id'];
            header('Location: ../index.php');
            exit();
        } else {
            $_SESSION['nao_autenticado'] = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/cadastro.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo" style="margin-right: 45%;">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>
    </header>

    <nav id="side-menu">
        <ul>
            <li><button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button></li> <br><br>
            <li><a href="paginas/historia.php">História</a></li>
            <li><a href="paginas/Acervo.php">Acervo Online</a></li>
            <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
            <li><a href="paginas/Bilheteria.php">Eventos</a></li>
        </ul>
    </nav>
    <form id="form-cadastro" action="" method="POST" onsubmit="return cadastrar(event)">
        <p id="pcad">Cadastro </p>
        <?php
        if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>

        <div name="erro" id="erro"></div>
        <div name="sucesso" id="sucesso"></div>

        <div class="dados">
            <input id="nome" type="text" name="nome" placeholder="Digite o nome e o sobrenome">
            <label id="nomeLabel">Nome Completo</label>
        </div>

        <div class="dados">
            <input id="email" type="text" name="email" placeholder="Digite o seu e-mail">
            <label id="emailLabel">Email</label>
        </div>

        <div class="dados">
            <input id="user" type="text" name="usuario" placeholder="Digite o usuário">
            <label id="userLabel">Usuário</label>
        </div>

        <div class="dados">
            <input id="senha" type="password" name="senha" placeholder="Digite a senha">
            <label id="senhaLabel" name="confirmsenha" for="senha">Senha</label>
        </div>

        <div class="dados">
            <input id="confirmSenha" type="password" name="confirmsenha" placeholder="Confirme a sua senha">
            <label id="confirmSenhaLabel" for="confirmSenha">Confirme a senha</label>
        </div>
        <input type="submit" name="btnCadUsuario" id="btnCad" onclick="cadastrar(event)" value="Cadastrar"></input>
    </form>
    <script src="../JS/script.js"></script>
    <script src="../JS/cadastro.js"></script>
</body>


<?php
    echo footer();
?>

</html>