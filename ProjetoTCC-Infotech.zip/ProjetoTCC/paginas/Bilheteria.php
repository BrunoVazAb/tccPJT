<?php
session_start();
include "conexao.php";
include "funcoes.php";

if (isset($_SESSION['id_usuario'])) {
    $idUsuario = $_SESSION['id_usuario'];
    $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
    $resultado_usuario = mysqli_query($conexao, $result_usuario);
    $row_usuario = mysqli_fetch_assoc($resultado_usuario);
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/bilheteria.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="compraIngressos.php">Ingressos</a></li>
                <li><a href="Bilheteria.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>

        <nav id="menu-userlog">
            <?php
            usuarioLogado()
            ?>
        </nav>

    </header>

    <nav id="side-menu">
        <ul>
            <li><button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button></li> <br><br>
            <li><a href="paginas/historia.php">História</a></li>
            <li><a href="paginas/Acervo.php">Acervo Online</a></li>
            <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
            <li><a href="paginas/Bilheteria.php">Eventos</a></li>
        </ul>
    </nav>

    <script src="../JS/script.js"></script>

    <div id="secao1">
        <img id="img1" src="../imagens/bilheteria/obra1.jpeg" />
        <p id="p1">Mergulhe por dentro de obras de arte internacionais, presentes exclusivamente no museu Paulo Agostinho Sobrinho. Agenda sua visita, acessando a aba de compra de ingressos, você também pode verificar a localização do museu e os horários de funcionamento, assim como sua agenda de ingressos!</p>
        <a href="compraIngressos.php"><input type="submit" id="botao" value="Compre seu ingresso!" /></a>
    </div>
    <div id="secao2">
        <img id="img2" src="../imagens/bilheteria/obra2.jpeg" />
        <p id="p2">Quer descobrir mais sobre a arte nacional? explore, exclusivamente no museu Paulo Agostinho Sobrinho, as obras de artes e os artefatos indígenas. Agenda sua visita, acessando a aba de compra de ingressos, você também pode verificar a localização do museu e os horários de funcionamento, assim como sua agenda de ingressos!</p>
        <a href="compraIngressos.php"><input type="submit" id="botao2" value="Compre seu ingresso!" /></a>
    </div>
    <div id="secao3">
        <img id="img3" src="../imagens/bilheteria/obra3.jpeg" />
        <p id="p3">Quer descobrir mais sobre a arte nacional? explore, exclusivamente no museu Paulo Agostinho Sobrinho, as obras de artes nacionais. Agenda sua visita, acessando a aba de compra de ingressos, você também pode verificar a localização do museu e os horários de funcionamento, assim como sua agenda de ingressos!</p>
        <a href="compraIngressos.php"><input type="submit" id="botao3" value="Compre seu ingresso!" /></a>
    </div>
    <script src="../JS/script.js"></script>
</body>

<footer>
    <div id="footer_content">
        <div id="footer_contacts">
            <h1>Conecte-se conosco </h1>

            <div id="footer_social_media">
                <a href="#" class="footer-link" id="instagram">
                    <i class="fa-brands fa-instagram"></i>
                </a>
                <a href="#" class="footer-link" id="youtube">
                    <i class="fa-brands fa-youtube"></i>
                </a>
                <a href="#" class="footer-link" id="twitter">
                    <i class="fa-brands fa-twitter"></i>
                </a>
            </div>

        </div>
        <ul class="footer-list">
            <li>
                <h3> Blog </h3>
            </li>
            <li>
                <a href="#" class="footer-link"> Home</a>
            </li>
            <li>
                <a href="Desenvolvedores.php" class="footer-link"> Sobre nós</a>
            </li>

        </ul>

        <ul class="footer-list">
            <li>
                <h3> Produtos </h3>
            </li>
            <li>
                <a href="#" class="footer-link"> App</a>
            </li>
            <li>
                <a href="#" class="footer-link"> Desktop</a>

        </ul>
        <div id="footer_subscribe">
            <h3> Subscribe</h3>
            <p>
                Enter your email to get notified about our news solutions
            </p>
            <div id="input_group">
                <input type="email" id="email">
                <button>
                    <i class="fa-regular fa-envelope"></i>
                </button>
            </div>
        </div>
    </div>
    <div id="footer_copyright">
        &#169
        2023 Todos os direitos reservados
    </div>
</footer>

</html>