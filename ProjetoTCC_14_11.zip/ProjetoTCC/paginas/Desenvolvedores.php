<?php
session_start();
include "conexao.php";
include "funcoes.php";

if (isset($_SESSION['id_usuario'])) {
    $idUsuario = $_SESSION['id_usuario'];
    $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
    $resultado_usuario = mysqli_query($conexao, $result_usuario);
    $row_usuario = mysqli_fetch_assoc($resultado_usuario);
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paulo Agostinho Sobrinho</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/desenvolvedores.css">
</head>

<body>
    <header id="header">

        <nav id="menu-h">
            <ul>
                <li><a href="historia.php">História</a></li>
                <li><a href="Acervo.php">Acervo Online</a></li>
                <li><a href="Bilheteria.php">Ingressos</a></li>
                <li><a href="Desenvolvedores.php">Eventos</a></li>
            </ul>

        </nav>

        <a button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
            <svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <div id="logo">
            <a href="../index.php"><img id="Img-logo" src="../imagens/Logo.png" alt="Logo do Site" /></a>

        </div>

        <nav id="menu-userlog">
            <?php
            usuarioLogado()
            ?>
        </nav>
        <div id="blur-background"></div>
        <div id="popup">
            <h1>Editar Perfil</h1>
            <?php

            $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
            $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
            $usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

            $result_usuario = "UPDATE amigos_museu SET nome='$nome', email='$email',usuario='$usuario' WHERE id='$id'";
            $resultado_usuario = mysqli_query($conexao, $result_usuario);

            if (isset($_SESSION['id_usuario'])) {
                $idUsuario = $_SESSION['id_usuario'];
                $result_usuario = "SELECT * FROM amigos_museu WHERE id = '$idUsuario'";
                $resultado_usuario = mysqli_query($conexao, $result_usuario);
                $row_usuario = mysqli_fetch_assoc($resultado_usuario);
            }

            if (mysqli_affected_rows($conexao)) {
                $_SESSION['msg'] = "<p style='color:green;'>Usuário editado com sucesso</p>";
            }
            ?>

            <form id="formEditarPerfil" method="POST" action="">
                <input type="hidden" name="id" value="<?php echo $row_usuario['id']; ?>">


                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Digite o nome completo" value="<?php echo $row_usuario['nome']; ?>"><br><br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Digite o seu melhor e-mail" value="<?php echo $row_usuario['email']; ?>"><br><br>

                <label for="usuario">Usuário:</label>
                <input type="text" id="usuario" name="usuario" placeholder="Digite o seu novo usuário" value="<?php echo $row_usuario['usuario']; ?>"><br><br>

                <a href=""><button type="button" id="salvarAlteracoes">Salvar Alterações</button></a>
                <span id="fecharPopup"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAABJUlEQVR4nO3YT0sCQRyH8YeuUu0KG/RHUG8efAceetFBJ6noEKUI6iG1wHolxcIYg6wi67Qzs3w/IHga92F09zeCiIiIiMg/6QEPwKXDNRvAHXBLhYbADzAHLhysdwo8W2ueUJEMmJoPfj9yZ/KdeDRrfQNdKpYCY3MBC+DKQUQHT46JsSO+fEYUxSwPjMkjnkKKsGNGVsw1u50BLyFGFMWsdsQEH7GR7Ik534poE7hkK+YmxoiNJjAxF/4BvJr3n0CLyCTAmwnIX+uYdqJ2Ic06fLWSgjtXdD/2dM/tN5pnSHrA0z3Y0aTMvBVsTFpiAg5mfHc9xnuNyaxT4qLkKbFhzv7eTocZMHN41PUWM6zLnw99E+Miwo65BwYO1xQRERER4c8v6Th7MMbV15kAAAAASUVORK5CYII="></span>
            </form>

        </div>
    </header>

    <nav id="side-menu">
        <ul>
            <li><button onclick="menuShow()" id="menu-toggle" class="btn_icon_header">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
                        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg>
                </button></li> <br><br>
            <li><a href="paginas/historia.php">História</a></li>
            <li><a href="paginas/Acervo.php">Acervo Online</a></li>
            <li><a href="paginas/compraIngressos.php">Ingressos</a></li>
            <li><a href="paginas/Bilheteria.php">Eventos</a></li>
        </ul>
    </nav>
    <div class="container">
        <input type="radio" name="dot" id="one">
        <input type="radio" name="dot" id="two">
        <div class="main-card">
            <div class="cards">
                <div class="card" id="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/Bruno.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Bruno Vaz</div>
                        </div>
                        <div class="media-icons">
                            <a href="https://github.com/BrunoVazAb"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="https://www.linkedin.com/in/bruno-abreu-68213b248/"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="https://www.instagram.com/bhzz__/"><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card" id="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/Caio.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Caio Cesar</div>
                        </div>
                        <div class="media-icons">
                            <a href="https://github.com/xlspectrolx"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="https://br.linkedin.com/in/caio-cesar-984b73259"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="https://instagram.com/_cai0_cesar?utm_source=qr&igshid=MThlNWY1MzQwNA=="><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card" id="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/danilo.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Danilo Fiuza</div>
                        </div>
                        <div class="media-icons">
                            <a href="https://github.com/DaniloLopesFiuza"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="https://www.linkedin.com/in/danilo-lopes-92676329a/"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="https://www.instagram.com/dorivaass/?next=%2F"><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cards" id="card">
                <div class="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/danilo.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Danilo Fiuza</div>
                        </div>
                        <div class="media-icons">
                            <a href="https://github.com/DaniloLopesFiuza"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="https://www.linkedin.com/in/danilo-lopes-92676329a/"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="https://www.instagram.com/dorivaass/?next=%2F"><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card" id="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/henrique.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Jose Henique</div>
                        </div>
                        <div class="media-icons">
                            <a href="https://github.com/Rickao1810"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="https://www.linkedin.com/in/jose-henrique-539051219/"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="https://www.instagram.com/jhenriquee_04/"><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card" id="card">
                    <div class="content">
                        <div class="img">
                            <img src="../imagens/desenvolvedores/Lucas.jpg" alt="">
                        </div>
                        <div class="details">
                            <div class="nome">Lucas Gomes</div>
                        </div>
                        <div class="media-icons">
                            <a href="#"><i class="fa-brands fa-github fa-xl"></i></i></i></a>
                            <a href="#"><i class="fa-brands fa-linkedin fa-xl"></i></i></a>
                            <a href="#"><i class="fa-brands fa-instagram fa-xl"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="button">
            <label for="one" class=" active one"></label>
            <label for="two" class="two"></label>
        </div>
    </div>

    <script src="../JS/script.js"></script>
</body>

<?php
    echo footer();
?>

</html>